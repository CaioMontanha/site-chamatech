'use client'

import { useEffect, useMemo, useState } from 'react'
import { Bell, CalendarDays, ChevronLeft, ChevronRight, ClipboardList, DollarSign, ExternalLink, Filter, LayoutDashboard, Menu, Pencil, Plus, Search, TrendingUp, X } from 'lucide-react'
import { createClient } from '@supabase/supabase-js'

const logoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo_montanha_2_VERSAO_2-0BzKgrQ1BBUQCCGLdlcIkOaGfuTTfd.png'
const supabase = process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  ? createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
  : null
const categorias = ['Suporte', 'Instalação', 'Bug', 'Treinamento']
const progressoPorStatus = { Pendente: 0, 'Em andamento': 50, Concluído: 100 }
const hoje = new Date()
const saudacaoPorHorario = (hora: number) => hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite'
const dataLocal = (data: Date = new Date()) => `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}-${String(data.getDate()).padStart(2, '0')}`
const nomesMeses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']

type Status = keyof typeof progressoPorStatus
type Chamado = { id: string; codigo: string; cliente: string; descricao: string; categoria: string; data_atendimento: string; valor: number; progresso: number; status: Status }

const iniciais: Chamado[] = [
  { id: '1', codigo: 'CH-1048', cliente: 'Mariana Costa', descricao: 'Ajuste de acesso ao sistema', categoria: 'Suporte', data_atendimento: dataLocal(), valor: 85, progresso: 100, status: 'Concluído' },
  { id: '2', codigo: 'CH-1047', cliente: 'Rafael Mendes', descricao: 'Configuração de impressora', categoria: 'Instalação', data_atendimento: dataLocal(), valor: 120, progresso: 100, status: 'Concluído' },
  { id: '3', codigo: 'CH-1046', cliente: 'Ana Beatriz', descricao: 'Erro no relatório financeiro', categoria: 'Bug', data_atendimento: dataLocal(), valor: 150, progresso: 50, status: 'Em andamento' },
]

export default function Page() {
  const [chamados, setChamados] = useState(iniciais)
  const [busca, setBusca] = useState('')
  const [filtro, setFiltro] = useState('Todos')
  const [modal, setModal] = useState(false)
  const [editando, setEditando] = useState<Chamado | null>(null)
  const [notificacoes, setNotificacoes] = useState(2)
  const [mes, setMes] = useState(hoje.getMonth())
  const [ano, setAno] = useState(hoje.getFullYear())
  const [diaSelecionado, setDiaSelecionado] = useState(hoje.getDate())

  useEffect(() => {
    if (!supabase) return
    const cliente = supabase
    let ativo = true
    async function carregarDados() {
      const { data: chamadosSalvos } = await cliente.from('chamados').select('id,codigo,cliente,descricao,categoria,data_atendimento,valor,progresso,status').order('data_atendimento', { ascending: false })
      if (!ativo) return
      if (chamadosSalvos?.length) setChamados(chamadosSalvos as Chamado[])
    }
    carregarDados()
    return () => { ativo = false }
  }, [])

  const filtrados = useMemo(() => chamados.filter((item) => {
    const texto = `${item.codigo} ${item.cliente} ${item.descricao}`.toLowerCase()
    return texto.includes(busca.toLowerCase()) && (filtro === 'Todos' || item.categoria === filtro)
  }), [chamados, busca, filtro])
  const concluidos = chamados.filter((item) => item.status === 'Concluído').length
  const total = chamados.reduce((soma, item) => soma + item.valor, 0)
  const mediaAvanco = chamados.length ? Math.round(chamados.reduce((soma, item) => soma + item.progresso, 0) / chamados.length) : 0
  const diasComServico = new Set(chamados.map((item) => item.data_atendimento)).size
  const diasNoMes = new Date(ano, mes + 1, 0).getDate()
  const primeiroDia = new Date(ano, mes, 1).getDay()
  const chaveDia = (dia: number) => `${ano}-${String(mes + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`
  const mudarMes = (direcao: number) => { const data = new Date(ano, mes + direcao, 1); setMes(data.getMonth()); setAno(data.getFullYear()); setDiaSelecionado(1) }

  async function adicionarChamado(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const dados = new FormData(event.currentTarget)
    const status = String(dados.get('status') || 'Pendente') as Status
    const registro = { codigo: `CH-${1050 + chamados.length}`, cliente: String(dados.get('cliente')), descricao: String(dados.get('descricao')), categoria: String(dados.get('categoria')), data_atendimento: String(dados.get('data')), valor: Number(dados.get('valor')), progresso: progressoPorStatus[status], status }
    const { data } = supabase ? await supabase.from('chamados').insert(registro).select().single() : { data: null }
    setChamados((atuais) => [data ? data as Chamado : { ...registro, id: crypto.randomUUID() }, ...atuais])
    setModal(false)
  }

  async function atualizarChamado(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!editando) return
    const dados = new FormData(event.currentTarget)
    const status = String(dados.get('status') || 'Pendente') as Status
    const atualizacao = { cliente: String(dados.get('cliente')), descricao: String(dados.get('descricao')), categoria: String(dados.get('categoria')), data_atendimento: String(dados.get('data')), valor: Number(dados.get('valor')), status, progresso: progressoPorStatus[status] }
    if (supabase) await supabase.from('chamados').update(atualizacao).eq('id', editando.id)
    setChamados((atuais) => atuais.map((item) => item.id === editando.id ? { ...item, ...atualizacao } : item))
    setEditando(null)
  }

  function marcarDia(dia: number) {
    setDiaSelecionado(dia)
  }

  async function atualizarStatus(id: string, status: Status) {
    const progresso = progressoPorStatus[status]
    setChamados((atuais) => atuais.map((item) => item.id === id ? { ...item, status, progresso } : item))
    if (supabase) await supabase.from('chamados').update({ status, progresso }).eq('id', id)
  }

  return <div className="min-h-screen bg-[#f7f8fa] text-slate-900">
    <aside className="fixed inset-y-0 left-0 z-20 hidden w-[252px] flex-col border-r border-slate-200 bg-white px-5 py-6 lg:flex">
      <div className="flex items-center gap-3 px-2"><img src={logoUrl} alt="Logo do portfólio" className="size-10 rounded-xl border border-orange-200 bg-white object-contain p-0.5" /><div><p className="text-[15px] font-bold tracking-tight">Chamados<span className="text-[#ef8d49]">.</span></p><p className="text-[10px] font-medium uppercase tracking-[0.18em] text-slate-400">workspace</p></div></div>
      <nav className="mt-10 flex flex-col gap-2"><p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">Menu principal</p><button className="flex items-center gap-3 rounded-xl bg-[#eaf1f7] px-3 py-3 text-sm font-semibold text-[#163d62]"><LayoutDashboard /> Visão geral</button><button className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-500 hover:bg-slate-50"><CalendarDays /> Calendário</button><button className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-500 hover:bg-slate-50"><ClipboardList /> Meus chamados <span className="ml-auto rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-bold">{chamados.length}</span></button></nav>
      <div className="mt-auto border-t border-slate-100 pt-5"><div className="flex items-center gap-3 rounded-xl bg-slate-50 p-3"><div className="flex size-9 items-center justify-center rounded-full bg-[#f6d7bc] text-xs font-bold text-[#8b5132]">AS</div><div><p className="text-xs font-bold">André Silva</p><p className="text-[11px] text-slate-400">Técnico independente</p></div></div></div>
    </aside>
    <main className="lg:pl-[252px]"><header className="flex h-[76px] items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-8"><div className="flex items-center gap-3"><button className="lg:hidden" aria-label="Abrir menu"><Menu /></button><img src={logoUrl} alt="Logo do portfólio" className="size-10 rounded-xl border border-orange-200 bg-white object-contain p-0.5" /><div><p className="text-xs font-medium text-slate-400">{hoje.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p><h1 className="text-lg font-bold tracking-tight">{saudacaoPorHorario(hoje.getHours())}, Caio</h1></div></div><button onClick={() => setNotificacoes(0)} className="relative flex size-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500" aria-label="Notificações"><Bell />{notificacoes > 0 && <span className="absolute right-1 top-1 flex size-4 items-center justify-center rounded-full bg-[#ef8d49] text-[9px] font-bold text-white">{notificacoes}</span>}</button></header>
      <div className="mx-auto max-w-[1400px] px-5 py-7 sm:px-8"><section className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-sm font-medium text-[#ef8d49]">Seu resumo mensal</p><h2 className="mt-1 text-3xl font-bold tracking-tight text-[#163d62]">Visão geral</h2><p className="mt-1 text-sm text-slate-500">Dados calculados diretamente dos seus chamados registrados.</p></div><div className="flex flex-wrap gap-2"><button onClick={() => setModal(true)} className="flex w-fit items-center gap-2 rounded-xl bg-[#ef8d49] px-4 py-2.5 text-sm font-bold text-white"><Plus /> Novo chamado</button><button onClick={() => filtrados[0] && setEditando(filtrados[0])} className="flex w-fit items-center gap-2 rounded-xl border border-[#163d62] px-4 py-2.5 text-sm font-bold text-[#163d62]"><Pencil /> Editar chamado</button></div></section>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><Stat label="Chamados atendidos" value={String(concluidos)} helper={`${chamados.length} registrados no total`} icon={<ClipboardList />} /><Stat label="Dias trabalhados" value={String(diasComServico)} helper="dias únicos com serviço" icon={<CalendarDays />} /><Stat label="Total a receber" value={`R$ ${total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`} helper="soma dos valores registrados" icon={<DollarSign />} /><Stat label="Avanço médio" value={`${mediaAvanco}%`} helper="progresso real dos chamados" icon={<TrendingUp />} /></section>
      <section className="mt-6 grid gap-6 xl:grid-cols-[1.2fr_1fr]"><div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="flex items-center justify-between"><div><h3 className="font-bold text-[#163d62]">Andamento no mês</h3><p className="mt-1 text-xs text-slate-400">Chamados registrados em {nomesMeses[mes].toLowerCase()}</p></div><span className="rounded-full bg-[#e7f6ef] px-3 py-1 text-xs font-bold text-emerald-600">{mediaAvanco}% de avanço médio</span></div><div className="mt-8 flex h-44 items-end gap-3">{[0, 1, 2, 3, 4].map((semana) => { const inicio = semana * 7 + 1; const fim = Math.min(inicio + 6, diasNoMes); const grupo = chamados.filter((item) => { const data = new Date(`${item.data_atendimento}T12:00:00`); return data.getFullYear() === ano && data.getMonth() === mes && data.getDate() >= inicio && data.getDate() <= fim }); const percentual = grupo.length ? Math.round(grupo.reduce((soma, item) => soma + item.progresso, 0) / grupo.length) : 0; return <div className="flex h-full flex-1 flex-col justify-end" key={semana}><div className="rounded-t-md bg-[#ef8d49] transition-all" title={`${grupo.length} chamados · ${percentual}% de avanço`} style={{ height: `${percentual || (grupo.length ? 6 : 2)}%` }} /><span className="mt-2 text-center text-[10px] text-slate-400">${inicio}-${fim}</span></div> })}</div><div className="mt-5 flex justify-between border-t border-slate-100 pt-4 text-xs text-slate-500"><span>{chamados.filter((item) => item.data_atendimento.startsWith(`${ano}-${String(mes + 1).padStart(2, '0')}`)).length} chamados no mês</span><strong className="text-[#163d62]">{concluidos} concluídos</strong></div></div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="flex items-center justify-between"><div><h3 className="font-bold text-[#163d62]">Calendário de trabalho</h3><p className="mt-1 text-xs text-slate-400">Hoje é {hoje.toLocaleDateString('pt-BR')}</p></div><CalendarDays className="text-[#ef8d49]" /></div><div className="mt-5 flex items-center justify-between"><button onClick={() => mudarMes(-1)} aria-label="Mês anterior"><ChevronLeft /></button><p className="text-sm font-bold text-[#163d62]">{nomesMeses[mes]} {ano}</p><button onClick={() => mudarMes(1)} aria-label="Próximo mês"><ChevronRight /></button></div><div className="mt-4 grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400">{['D','S','T','Q','Q','S','S'].map((d, i) => <span key={`${d}${i}`} className="py-1">{d}</span>)}{Array.from({ length: primeiroDia }).map((_, i) => <span key={`v${i}`} />)}{Array.from({ length: diasNoMes }, (_, i) => i + 1).map((dia) => <button key={dia} onClick={() => marcarDia(dia)} className={`relative aspect-square rounded-lg text-xs font-medium ${dia === diaSelecionado ? 'bg-[#163d62] text-white' : 'text-slate-600 hover:bg-slate-100'}`}>{dia}{chamados.filter((item) => item.data_atendimento === chaveDia(dia)).length > 0 ? <span className="absolute bottom-1 left-1/2 size-1.5 -translate-x-1/2 rounded-full bg-[#ef8d49]" /> : null}</button>)}</div><p className="mt-4 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-500">Dia selecionado: <strong>{diaSelecionado}/{mes + 1}/{ano}</strong> · {chamados.filter((item) => item.data_atendimento === chaveDia(diaSelecionado)).length} chamados atendidos</p></div></section>
      <section className="mt-6 rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex flex-col gap-4 border-b border-slate-100 p-5 sm:flex-row sm:items-center sm:justify-between"><div><h3 className="font-bold text-[#163d62]">Chamados recentes</h3><p className="mt-1 text-xs text-slate-400">Pesquise por código, cliente ou descrição</p></div><div className="flex flex-wrap gap-2"><div className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-400"><Search /><input value={busca} onChange={(e) => setBusca(e.target.value)} aria-label="Buscar chamados" placeholder="Buscar chamado..." className="w-40 bg-transparent outline-none" /></div><select value={filtro} onChange={(e) => setFiltro(e.target.value)} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold"><option>Todos</option>{categorias.map((categoria) => <option key={categoria}>{categoria}</option>)}</select><button onClick={() => { setBusca(''); setFiltro('Todos') }} className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold"><Filter /> Limpar</button></div></div><div className="overflow-x-auto"><table className="w-full min-w-[780px] text-left"><thead><tr className="border-b border-slate-100 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400"><th className="px-6 py-3">Chamado</th><th className="px-4 py-3">Cliente</th><th className="px-4 py-3">Categoria</th><th className="px-4 py-3">Data</th><th className="px-4 py-3">Avanço</th><th className="px-4 py-3">Valor</th><th className="px-4 py-3">Ações</th></tr></thead><tbody>{filtrados.map((item) => <tr key={item.id} className="border-b border-slate-50 text-sm hover:bg-slate-50"><td className="px-6 py-4"><strong className="text-[#163d62]">{item.codigo}</strong><p className="mt-1 text-xs text-slate-400">{item.descricao}</p></td><td className="px-4 py-4 font-medium">{item.cliente}</td><td className="px-4 py-4"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs">{item.categoria}</span></td><td className="px-4 py-4 text-xs text-slate-500">{new Date(`${item.data_atendimento}T12:00:00`).toLocaleDateString('pt-BR')}</td><td className="px-4 py-4"><div className="flex items-center gap-2"><div className="h-1.5 w-20 rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#ef8d49]" style={{ width: `${item.progresso}%` }} /></div><span className="text-xs font-bold">{item.progresso}%</span></div><p className="mt-1 text-[10px] text-slate-400">{item.status}</p></td><td className="px-4 py-4 font-bold text-[#163d62]">R$ {item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td></tr>)}</tbody></table></div></section></div></main>
    <a href="https://seuportfolio.com" target="_blank" rel="noreferrer" className="fixed bottom-5 right-5 z-30 flex items-center gap-2 rounded-full bg-[#ff6b16] p-2 pr-4 text-xs font-bold text-white shadow-lg shadow-orange-200 transition hover:scale-105"><img src={logoUrl} alt="Abrir portfólio" className="size-10 rounded-full bg-white object-contain p-1" /><span className="hidden sm:inline">Meu portfólio <ExternalLink /></span></a>
    {editando && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4"><form onSubmit={atualizarChamado} className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl"><div className="flex items-start justify-between"><div><h2 className="text-lg font-bold text-[#163d62]">Editar {editando.codigo}</h2><p className="mt-1 text-xs text-slate-400">Atualize os dados e o status deste chamado.</p></div><button type="button" onClick={() => setEditando(null)} aria-label="Fechar"><X /></button></div><div className="mt-5 flex flex-col gap-3"><label className="text-xs font-bold">Cliente<input name="cliente" defaultValue={editando.cliente} required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><label className="text-xs font-bold">O que foi feito<input name="descricao" defaultValue={editando.descricao} required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><div className="grid grid-cols-2 gap-3"><label className="text-xs font-bold">Categoria<select name="categoria" defaultValue={editando.categoria} className="mt-1 w-full rounded-lg border bg-white p-2.5 font-normal">{categorias.map((c) => <option key={c}>{c}</option>)}</select></label><label className="text-xs font-bold">Status<select name="status" defaultValue={editando.status} className="mt-1 w-full rounded-lg border bg-white p-2.5 font-normal"><option>Pendente</option><option>Em andamento</option><option>Concluído</option></select></label></div><div className="grid grid-cols-2 gap-3"><label className="text-xs font-bold">Data<input name="data" type="date" defaultValue={editando.data_atendimento} required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><label className="text-xs font-bold">Valor<input name="valor" type="number" min="0" step="0.01" defaultValue={editando.valor} required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label></div></div><button className="mt-5 w-full rounded-xl bg-[#163d62] py-3 text-sm font-bold text-white">Salvar alterações</button></form></div>}
    {modal && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4"><form onSubmit={adicionarChamado} className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl"><div className="flex items-start justify-between"><div><h2 className="text-lg font-bold text-[#163d62]">Novo chamado</h2><p className="mt-1 text-xs text-slate-400">Registre o atendimento e seu avanço.</p></div><button type="button" onClick={() => setModal(false)} aria-label="Fechar"><X /></button></div><div className="mt-5 flex flex-col gap-3"><label className="text-xs font-bold">Cliente<input name="cliente" required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><label className="text-xs font-bold">O que foi feito<input name="descricao" required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><div className="grid grid-cols-2 gap-3"><label className="text-xs font-bold">Categoria<select name="categoria" className="mt-1 w-full rounded-lg border bg-white p-2.5 font-normal">{categorias.map((c) => <option key={c}>{c}</option>)}</select></label><label className="text-xs font-bold">Status<select name="status" className="mt-1 w-full rounded-lg border bg-white p-2.5 font-normal"><option>Pendente</option><option>Em andamento</option><option>Concluído</option></select></label></div><div className="grid grid-cols-2 gap-3"><label className="text-xs font-bold">Data<input name="data" type="date" defaultValue={dataLocal(hoje)} required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label><label className="text-xs font-bold">Valor<input name="valor" type="number" min="0" step="0.01" required className="mt-1 w-full rounded-lg border p-2.5 font-normal" /></label></div></div><button className="mt-5 w-full rounded-xl bg-[#163d62] py-3 text-sm font-bold text-white">Salvar chamado</button></form></div>}
  </div>
}

function Stat({ icon, label, value, helper }: { icon: React.ReactNode; label: string; value: string; helper: string }) { return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex size-10 items-center justify-center rounded-xl bg-[#eaf1f7] text-[#163d62]">{icon}</div><p className="mt-5 text-xs font-medium text-slate-400">{label}</p><p className="mt-1 text-2xl font-bold tracking-tight text-[#163d62]">{value}</p><p className="mt-1 text-[11px] text-slate-400">{helper}</p></div> }
